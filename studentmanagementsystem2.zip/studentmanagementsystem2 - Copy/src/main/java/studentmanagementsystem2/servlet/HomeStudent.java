package studentmanagementsystem2.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/home_student")
public class HomeStudent extends HttpServlet {
	

}
